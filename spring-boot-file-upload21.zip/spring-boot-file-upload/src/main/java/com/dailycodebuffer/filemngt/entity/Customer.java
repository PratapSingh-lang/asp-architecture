package com.dailycodebuffer.filemngt.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long cust_id;
	
	private String name;
	
	@OneToMany( mappedBy = "customer", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Account> account;

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return cust_id;
	}

	public void setId(long id) {
		this.cust_id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Account> getAccount() {
		return account;
	}

	public void setAccount(List<Account> account) {
		this.account = account;
	}

	public Customer(long id, String name, List<Account> account) {
		super();
		this.cust_id = id;
		this.name = name;
		this.account = account;
	}
	
	
}
