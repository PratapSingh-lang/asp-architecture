package com.dailycodebuffer.filemngt;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

@SpringBootApplication(
//		exclude = 
//{SecurityAutoConfiguration.class}
//{DataSourceAutoConfiguration.class}
)
@ComponentScan
public class SpringBootFileUploadApplication {

    public static void main(String[] args) throws UnknownHostException {
        SpringApplication.run(SpringBootFileUploadApplication.class, args);
        InetAddress localHost = InetAddress.getLocalHost();
        System.out.println("host address : " +localHost.getHostAddress());
        
        String SystemName
        = InetAddress.getLocalHost().getHostName();
        
    // SystemName stores the name of the system
    System.out.println("System Name : "
                       + SystemName);
    }

}
