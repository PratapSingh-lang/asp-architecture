package com.dailycodebuffer.filemngt.controller;

import com.dailycodebuffer.filemngt.ResponseData;
import com.dailycodebuffer.filemngt.entity.Attachment;
import com.dailycodebuffer.filemngt.entity.Customer;
import com.dailycodebuffer.filemngt.entity.Student;
import com.dailycodebuffer.filemngt.repository.CustomerRepository;
import com.dailycodebuffer.filemngt.service.AttachmentService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.awt.*;
import java.util.List;

@RestController
public class AttachmentController {

    private AttachmentService attachmentService;
    
    @Autowired
    private ObjectMapper mapper;
    
    @Autowired
    private CustomerRepository customerRepository;

    public AttachmentController(AttachmentService attachmentService) {
        this.attachmentService = attachmentService;
    }

    @PostMapping(path = "/create", produces = "application/json")
    public ResponseEntity<?> createCustomer(@RequestBody Customer customer){
    	
    	Customer customer2 = this.customerRepository.save(customer);
    	
    	 return new ResponseEntity<> (
    			 customer2,
         		HttpStatus.OK
         		);
    }
    
    @GetMapping(path = "/get", produces = "application/json")
    public ResponseEntity<?> getAllCustomer(@RequestBody Customer customer){
    	
    	List<Customer> list = this.customerRepository.findAll();
    	
    	 return new ResponseEntity<> (
    			 list,
         		HttpStatus.OK
         		);
    }
    
    @PostMapping(path = "/upload", produces = "application/json")
//    @PostMapping(path = "/submitData", consumes = "application/json")
    public ResponseEntity<?> uploadFile(@RequestParam("file")MultipartFile file) throws Exception {
        Attachment attachment = null;
        String downloadURl = "";
        attachment = attachmentService.saveAttachment(file);
        downloadURl = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/download/")
                .path(attachment.getId())
                .toUriString();
        String fileName = attachment.getFileName();
        System.out.println(downloadURl);
        System.out.println(fileName);
       
        String contentType = file.getContentType();
        long size = file.getSize();
        System.out.println(contentType);
        System.out.println(size);
        ResponseData r = new ResponseData
		(
				attachment.getFileName(),
        downloadURl,
        file.getContentType(),
        file.getSize()
        );
//        Student s = new Student(1, "dshfd");
        
        return new ResponseEntity<> (
//        		downloadURl,
        		r,
//        		"hi is response",
//        		fileName,downloadURl,
//        		s,
//        		new ResponseData
//        		(
//        				attachment.getFileName(),
//                downloadURl,
//                file.getContentType(),
//                file.getSize()
//                ),
        		HttpStatus.OK
        		);
        
//        return new ResponseData(attachment.getFileName(),
//                downloadURl,
//                file.getContentType(),
//                file.getSize());
        
    }
    
    
    @PostMapping(path = "/user"
//    		, produces = "application/json"
    		)
//  @PostMapping(path = "/submitData", consumes = "application/json")
  public ResponseEntity<?> userDetails(@RequestParam("file")MultipartFile file
		  ,@RequestParam("userDetail") String userData
		  )
//				  throws Exception 
    {
      
    	try {
			Student readValue = mapper.readValue(userData, Student.class);
			System.out.println(readValue.toString() + "    kdcnln ");
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("this is invalid");
		}
    	System.out.println(file.getOriginalFilename());
    	System.out.println(userData);
    	
    	return new ResponseEntity<>("done", HttpStatus.OK);
      
      
  }
    

    @GetMapping("/download/{fileId}")
    public ResponseEntity<Resource> downloadFile(@PathVariable String fileId) throws Exception {
        Attachment attachment = null;
        attachment = attachmentService.getAttachment(fileId);
        return  ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(attachment.getFileType()))
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + attachment.getFileName()
                + "\"")
                .body(new ByteArrayResource(attachment.getData()));
    }
}
