package com.dailycodebuffer.filemngt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dailycodebuffer.filemngt.entity.Account;

@Repository
public interface AccountRepo extends JpaRepository<Account, Long> {

}
